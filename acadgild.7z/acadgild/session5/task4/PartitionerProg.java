package acadgild.session5.task4;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionerProg extends Partitioner<Text, NullWritable>{

	@Override
	public int getPartition(Text arg0, NullWritable arg1, int arg2) {
		
		String[] lineArray = arg0.toString().split("\\|");
		String compNameFirstAlphabet = lineArray[0].substring(0, 1);
		if(compNameFirstAlphabet.matches("[a-fA-F]"))
		{
			return 0;
		}
		else if(compNameFirstAlphabet.matches("[g-lG-L]"))
		{
			return 1;
		}
		else if(compNameFirstAlphabet.matches("[m-rM-R]"))
		{
			return 2;
		}
		else if(compNameFirstAlphabet.matches("[s-zS-Z]"))
		{
			return 3;
		}
		return 0;
	}
	

}
